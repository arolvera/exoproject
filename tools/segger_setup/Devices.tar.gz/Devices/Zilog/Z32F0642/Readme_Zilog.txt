The Zilog Semiconductor devices support comes without any warranty  and support
from SEGGER Microcontroller GmbH. Support is provided  via  Zilog only.

For support, please visit Zilog Technical Support page at: http://support.zilog.com.

To learn more about this product, find additional documentation, or to discover
other facets about  Zilog product offerings, please visit  the  Zilog Knowledge
Base or consider participating in the Zilog Forum.

