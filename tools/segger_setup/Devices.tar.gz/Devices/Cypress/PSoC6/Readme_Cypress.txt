The Cypress devices support comes without any warranty and support from SEGGER Microcontroller GmbH. Support is provided via Cypress only.
For support, please contact: cytechsupport@cypress.com